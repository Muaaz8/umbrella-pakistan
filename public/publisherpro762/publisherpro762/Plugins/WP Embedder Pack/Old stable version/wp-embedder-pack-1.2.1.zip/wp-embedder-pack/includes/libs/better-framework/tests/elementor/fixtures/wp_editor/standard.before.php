<?php

return array(
	'off_canvas_footer' => array(
		'name' => 'Footer help text',
		'desc' => 'Enter your contact info and personal tips/helps in this field.',
		'id'   => 'off_canvas_footer',
		'type' => 'wp_editor',
	),
);
