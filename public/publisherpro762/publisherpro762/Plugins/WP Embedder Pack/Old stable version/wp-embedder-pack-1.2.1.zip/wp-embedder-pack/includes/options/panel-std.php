<?php

$fields['use-google-drive'] = array(
	'std' => 0,
);


$fields['google-drive-client-id'] = array(
	'std' => '',
);


$fields['google-drive-api-key'] = array(
	'std' => '',
);

$fields['use-dropbox'] = array(
	'std' => 0,
);

$fields['dropbox-api-key'] = array(
	'std' => '',
);

$fields['translation-download'] = array(
	'std' => 'Download',
);
