<?php

return array(
	array(
		'name' => 'Field Title',
		'id'   => 'field-id',
		'type' => 'color',
	)
);
