
$('.wp-embedder-pack').click(function () {

    betterWpEmbedderAdmin.open();
});
