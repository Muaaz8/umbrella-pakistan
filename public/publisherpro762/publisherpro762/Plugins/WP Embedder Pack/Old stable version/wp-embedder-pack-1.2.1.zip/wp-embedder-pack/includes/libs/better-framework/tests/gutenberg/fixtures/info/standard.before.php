<?php

return array(
	'note' => array(
		'name'      => 'Important Note',
		'id'        => 'note',
		'type'      => 'info',
		'std'       => '<p>Following options wouldn\'t work if you selected a custom page for front page but these settings will be used when you have not selected a static page for front page and the paginated pages of static homepage.</p>',
		'state'     => 'open',
		'info-type' => 'danger',
	),
);