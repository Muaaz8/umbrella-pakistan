<?php

return array(
	'icon_select' => array(
		'id'   => 'icon_select',
		'name' => 'icon select',
		'type' => 'icon_select',
	),
);