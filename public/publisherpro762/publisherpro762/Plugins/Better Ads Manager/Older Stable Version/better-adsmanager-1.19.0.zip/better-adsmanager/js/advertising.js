/*
 * Hack file just to test Ad Blockers.
 * If adblockers are activated they will most likely hide this file.
 * If this file is hidden we know an AD Blocker is active.
 */
window.better_ads_adblock = true;