<?php

return array(
	'typo_mg_1_img' => array(
		'name'         => 'Default Thumbnail Image',
		'id'           => 'typo_mg_1_img',
		'data-type'    => 'id',
		'preview-size' => 'large',
		'desc'         => 'By default, the post thumbnail will be shown but when the post haven\'nt thumbnail then this will be replaced',
		'type'         => 'media_image',
		'media_title'  => 'Select or Image',
		'media_button' => 'Select Image',
		'upload_label' => 'Upload Image',
		'remove_label' => 'Remove',
		'show_input'   => true,
	),
);