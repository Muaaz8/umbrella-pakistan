<?php

return array(
	'hr1' => array(
		'id'   => 'hd1',
		'name' => 'Slider',
		'type' => 'heading',
		'desc' => "Description"
	),
);