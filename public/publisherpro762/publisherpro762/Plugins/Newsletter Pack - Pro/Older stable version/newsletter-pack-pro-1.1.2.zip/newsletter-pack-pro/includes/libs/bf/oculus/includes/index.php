<?php
// Silence is golden and we believe it