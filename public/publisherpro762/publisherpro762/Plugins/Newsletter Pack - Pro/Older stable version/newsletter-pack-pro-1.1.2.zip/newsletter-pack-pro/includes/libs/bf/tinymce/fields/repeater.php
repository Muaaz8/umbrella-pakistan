<?php

$options['clone-name-format'] = '$4[$5][$6]';

include BF_PATH . 'core/field-generator/fields/repeater.php';
