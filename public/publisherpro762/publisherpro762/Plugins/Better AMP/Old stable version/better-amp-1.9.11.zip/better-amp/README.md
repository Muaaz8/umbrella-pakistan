# Better AMP
Full Google AMP support for WordPress with custom themes and customizations - 

More information: https://betterstudio.com/wp-plugins/better-amp/

Demo: http://demo.betterstudio.com/publisher/amp-demo/
