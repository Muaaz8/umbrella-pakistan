<?php

return array(
	'typo_mg_1_img' => array(
		'id'    => 'typo_mg_1_img',
		'type'  => 'image_preview',
		'std'   => 'path/to/img.png',
		'align' => 'right',
	),
);