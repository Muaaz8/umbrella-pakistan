<?php

return array(
	'sample-id' => array(
		'name'      => 'Admin Pages CSS Code',
		'id'        => 'sample-id',
		'type'      => 'editor',
		'lang'      => 'css',
		'desc'      => 'You can change admin pages style with adding CSS code into this field.',
		//
		'max-lines' => 200,
		'min-lines' => 20,
	),
);