<?php

return array(
	array(
		'name' => 'Group title',
		'id'   => 'the_id',
		'type' => 'tab',
	),
	array(
		'name'  => 'Field Title',
		'id'    => 'text',
		'type'  => 'text',
		'style' => [],
	),
	array(
		'name' => 'Group2 title',
		'id'   => 'the_id2',
		'type' => 'tab',
	),
	array(
		'name'  => 'Field2 Title',
		'id'    => 'text2',
		'type'  => 'text',
		'style' => [],
	),
	array(
		'name'  => 'Group3 title',
		'id'    => 'the_id3',
		'type'  => 'tab',
		'state' => 'close',
	),
	array(
		'name' => 'Field3 Title',
		'id'   => 'text3',
		'type' => 'text',
	),
	array(
		'name' => 'Field3_2 Title',
		'id'   => 'text3_2',
		'type' => 'text',
	),
	array(
		'name' => 'Field3_3 Title',
		'id'   => 'text3_3',
		'type' => 'text',
	),
);
