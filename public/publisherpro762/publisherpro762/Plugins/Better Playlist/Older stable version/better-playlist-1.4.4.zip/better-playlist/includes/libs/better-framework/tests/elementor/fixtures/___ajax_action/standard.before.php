<?php

return array(
	'id1' => array(
		'id'          => 'id1',
		'name'        => 'Action',
		'type'        => 'ajax_action',
		'button-name' => '<i class="fa fa-refresh"></i> Reset Color Settings',
		'callback'    => 'callable',
		'confirm'     => 'Are you sure for resetting all color settings?',
		'ev'          => 'js-event',
	),
);