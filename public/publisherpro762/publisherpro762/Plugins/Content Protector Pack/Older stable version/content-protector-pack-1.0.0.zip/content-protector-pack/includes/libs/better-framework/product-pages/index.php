<?php
// Silent is golden!