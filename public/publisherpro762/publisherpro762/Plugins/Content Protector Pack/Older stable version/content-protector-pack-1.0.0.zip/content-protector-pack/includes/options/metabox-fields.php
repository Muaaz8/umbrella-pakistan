<?php

$fields['protect_post'] = array(
	'name'      => __( 'Do not protect this post', 'content-protector-pack' ),
	'id'        => 'protect_post',
	'type'      => 'switch',
	'on-label'  => __( 'Yes', 'content-protector-pack' ),
	'off-label' => __( 'No', 'content-protector-pack' ),
);
