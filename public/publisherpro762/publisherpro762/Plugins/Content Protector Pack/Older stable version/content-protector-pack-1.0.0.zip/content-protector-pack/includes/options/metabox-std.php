<?php

$fields ['protect_post'] = array(
	'std' => FALSE,
);
