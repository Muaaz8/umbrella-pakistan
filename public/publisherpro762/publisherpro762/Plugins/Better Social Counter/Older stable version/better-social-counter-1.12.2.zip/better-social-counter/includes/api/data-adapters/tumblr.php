<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'tumblr_link' ),
	'name'       => Better_Social_Counter::get_option( 'tumblr_name' ),
	'title'      => Better_Social_Counter::get_option( 'tumblr_title' ),
	'button'     => Better_Social_Counter::get_option( 'tumblr_button' ),
	'title_join' => Better_Social_Counter::get_option( 'tumblr_title_join' ),
);
