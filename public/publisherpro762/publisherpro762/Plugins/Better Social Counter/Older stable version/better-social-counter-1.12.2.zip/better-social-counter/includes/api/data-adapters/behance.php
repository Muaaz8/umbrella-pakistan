<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'behance_username' ),
	'name'       => Better_Social_Counter::get_option( 'behance_name' ),
	'title'      => Better_Social_Counter::get_option( 'behance_title' ),
	'button'     => Better_Social_Counter::get_option( 'behance_button' ),
	'title_join' => Better_Social_Counter::get_option( 'behance_title_join' ),
);
