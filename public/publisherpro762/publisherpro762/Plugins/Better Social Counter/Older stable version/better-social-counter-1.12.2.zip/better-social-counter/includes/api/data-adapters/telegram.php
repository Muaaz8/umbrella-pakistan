<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'telegram_link' ),
	'name'       => Better_Social_Counter::get_option( 'telegram_name' ),
	'title'      => Better_Social_Counter::get_option( 'telegram_title' ),
	'button'     => Better_Social_Counter::get_option( 'telegram_button' ),
	'title_join' => Better_Social_Counter::get_option( 'telegram_title_join' ),
);
