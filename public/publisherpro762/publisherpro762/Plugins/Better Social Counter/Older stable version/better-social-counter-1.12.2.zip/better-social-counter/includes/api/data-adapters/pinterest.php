<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'pinterest_username' ),
	'name'       => Better_Social_Counter::get_option( 'pinterest_name' ),
	'title'      => Better_Social_Counter::get_option( 'pinterest_title' ),
	'button'     => Better_Social_Counter::get_option( 'pinterest_button' ),
	'title_join' => Better_Social_Counter::get_option( 'pinterest_title_join' ),
);
