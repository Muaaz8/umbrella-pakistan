<?php

return array(

	'link'       => Better_Social_Counter::get_option( 'line_link' ),
	'name'       => Better_Social_Counter::get_option( 'line_name' ),
	'title'      => Better_Social_Counter::get_option( 'line_title' ),
	'button'     => Better_Social_Counter::get_option( 'line_button' ),
	'title_join' => Better_Social_Counter::get_option( 'line_title_join' ),
);
