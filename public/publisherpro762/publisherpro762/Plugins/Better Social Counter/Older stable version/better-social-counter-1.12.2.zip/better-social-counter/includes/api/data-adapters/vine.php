<?php

return array(
	'id'         => Better_Social_Counter::get_option( 'vine_profile' ),
	'pass'       => Better_Social_Counter::get_option( 'vine_pass' ),
	'name'       => Better_Social_Counter::get_option( 'vine_name' ),
	'email'      => Better_Social_Counter::get_option( 'vine_email' ),
	'title'      => Better_Social_Counter::get_option( 'vine_title' ),
	'button'     => Better_Social_Counter::get_option( 'vine_button' ),
	'title_join' => Better_Social_Counter::get_option( 'vine_title_join' ),
);
