<?php

return array(

	'name'       => Better_Social_Counter::get_option( 'soundcloud_name' ),
	'title'      => Better_Social_Counter::get_option( 'soundcloud_title' ),
	'button'     => Better_Social_Counter::get_option( 'soundcloud_button' ),
	'api_key'    => Better_Social_Counter::get_option( 'soundcloud_api_key' ),
	'id'         => Better_Social_Counter::get_option( 'soundcloud_username' ),
	'title_join' => Better_Social_Counter::get_option( 'soundcloud_title_join' ),
);
