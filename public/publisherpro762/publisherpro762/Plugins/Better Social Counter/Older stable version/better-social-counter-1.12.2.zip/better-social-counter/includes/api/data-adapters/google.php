<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'google_page' ),
	'name'       => Better_Social_Counter::get_option( 'google_name' ),
	'title'      => Better_Social_Counter::get_option( 'google_title' ),
	'button'     => Better_Social_Counter::get_option( 'google_button' ),
	'title_join' => Better_Social_Counter::get_option( 'google_title_join' ),
);
