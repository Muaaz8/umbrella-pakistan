<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'dribbble_username' ),
	'name'       => Better_Social_Counter::get_option( 'dribbble_name' ),
	'title'      => Better_Social_Counter::get_option( 'dribbble_title' ),
	'button'     => Better_Social_Counter::get_option( 'dribbble_button' ),
	'title_join' => Better_Social_Counter::get_option( 'dribbble_title_join' ),
);
