<?php

return array(

	'list_id'    => Better_Social_Counter::get_option( 'mailchimp_list_id' ),
	'api_key'    => Better_Social_Counter::get_option( 'mailchimp_api_key' ),
	'list_url'   => Better_Social_Counter::get_option( 'mailchimp_list_url' ),
	//
	'title'      => Better_Social_Counter::get_option( 'mailchimp_title' ),
	'button'     => Better_Social_Counter::get_option( 'mailchimp_button' ),
	'name'       => Better_Social_Counter::get_option( 'mailchimp_name' ),
	'title_join' => Better_Social_Counter::get_option( 'mailchimp_title_join' ),
);
