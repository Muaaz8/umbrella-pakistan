<?php

return '<p>Without injuring others or placing your own life in danger, it’s healthy to let go sometimes. You don’t have to be irresponsible to release responsibility and embrace freedom for a change. When life is becoming too burdensome and the weight of obligation and duty seems suffocating, do something that allows you to release yourself from what can feel like a prison.</p>
	
	<h4>Item 4 title</h4>
	
	<p><a href="http://betterstudio.com"><img class="alignnone size-full wp-image-123" src="http://via.placeholder.com/350x150" alt="" width="800" height="541" /></a> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
	
	<span class="bs-smart-list-start"></span>

	<h4>Item 1 title</h4>

	<p>
		Item 1 content <img class="alignnone size-full wp-image-7526" src="http://via.placeholder.com/350x150" alt="test alt" width="800" height="541" /> after image
	</p>
		
	<h4>Item 2 title</h4>

	<a href="http://betterstudio.com"><img class="alignnone size-full wp-image-7526" src="http://via.placeholder.com/350x150" alt="" width="800" height="541" /></a>
	&nbsp;
	<h4>Item 3 title</h4>
	
	<p><a href="http://betterstudio.com"><img class="alignnone size-full wp-image-123" src="http://via.placeholder.com/350x150" alt="" width="800" height="541" /></a> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
	
	<span class="bs-smart-list-end"></span>
	
	<p>Without injuring others or placing your own life in danger, it’s healthy to let go sometimes. You don’t have to be irresponsible to release responsibility and embrace freedom for a change. When life is becoming too burdensome and the weight of obligation and duty seems suffocating, do something that allows you to release yourself from what can feel like a prison.</p>
	
	<h4>Item 4 title</h4>
	
	<p><a href="http://betterstudio.com"><img class="alignnone size-full wp-image-123" src="http://via.placeholder.com/350x150" alt="" width="800" height="541" /></a> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
	
';