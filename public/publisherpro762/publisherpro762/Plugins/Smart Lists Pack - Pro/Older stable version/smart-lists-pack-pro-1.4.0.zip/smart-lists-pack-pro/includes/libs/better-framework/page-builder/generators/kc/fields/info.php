<div class="info-value">
	<?php echo $options['std']; // escaped before ?>
</div>