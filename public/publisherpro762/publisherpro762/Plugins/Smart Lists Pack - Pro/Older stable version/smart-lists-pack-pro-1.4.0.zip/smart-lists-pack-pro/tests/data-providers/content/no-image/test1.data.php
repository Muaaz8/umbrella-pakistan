<?php

return '

	<h4>Item 1 title</h4>

	<p>
		Item 1 content
	</p>
		
	<img class="alignnone size-full wp-image-7526" src="http://via.placeholder.com/350x150" alt="test alt" width="800" height="541" />
	
	<h4>Item 2 title</h4>

	<p>
		Item 2 content
	</p>

	&nbsp;
	<h4>Item 3 title</h4>
	
	<a href="http://betterstudio.com"><img class="alignnone size-full wp-image-123" src="http://via.placeholder.com/350x150" alt="" width="800" height="541" /></a>
	
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
	
';