<?php

return '

	<h4>Item 1 title</h4>

	<p>
		Item 1 content <figure id="attachment_7528" style="width: 800px" class="wp-caption alignnone"><a href="#test"><img class="wp-image-7528 size-full"  data-src="http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22.jpg" alt="test alt" width="800" height="541" srcset="http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22.jpg 800w, http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22-300x203.jpg 300w, http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22-768x519.jpg 768w" sizes="(max-width: 800px) 100vw, 800px" /></a><figcaption class="wp-caption-text">the caption</figcaption></figure> after image
	</p>
		
	<h4>Item 2 title</h4>

	<figure id="attachment_7528" style="width: 800px" class="wp-caption alignnone"><img class="wp-image-7528 size-full" src="http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22.jpg" alt="test alt" width="800" height="541" srcset="http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22.jpg 800w, http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22-300x203.jpg 300w, http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22-768x519.jpg 768w" sizes="(max-width: 800px) 100vw, 800px" /><figcaption class="wp-caption-text">the caption</figcaption></figure>
	&nbsp;
	<h4>Item 3 title</h4>
	
	<figure id="attachment_7528" style="width: 800px" class="wp-caption alignnone"><img class="wp-image-7528 size-full" src="http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22.jpg" alt="test alt" width="800" height="541" srcset="http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22.jpg 800w, http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22-300x203.jpg 300w, http://publisher.dev/wp-content/uploads/2017/08/pure-magazine-thumb-22-768x519.jpg 768w" sizes="(max-width: 800px) 100vw, 800px" /></figure>
	
	<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
	
	<span class="bs-smart-list-end"></span>
	
	<p>Without injuring others or placing your own life in danger, it’s healthy to let go sometimes. You don’t have to be irresponsible to release responsibility and embrace freedom for a change. When life is becoming too burdensome and the weight of obligation and duty seems suffocating, do something that allows you to release yourself from what can feel like a prison.</p>
	
	<h4>Item 4 title</h4>
	
	<p><a href="http://betterstudio.com"><img class="alignnone size-full wp-image-123" src="http://via.placeholder.com/350x150" alt="" width="800" height="541" /></a> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod</p>
	
';